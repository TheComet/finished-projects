

 _____  ___  _______  _  ____  _____  ___  __    _  ____
�     ��   �� _  _  ��.\� ___ �     ��   ��   \ � �� __
 -- -- � � �� �� �� �� /�__  � -- -- � � �� �\ \� ��  _�
  � �  � � �� �� �� ��.\ __� �  � �  � � �� � \   �� �_
  �_�  �___��_��_��_��_/�____�  �_�  �___��_�  \__��___�

                  -=Slinki Software=-


                  all rights reserved


Requires DirectX 7.0 or later to play
==================================================



------
Setup:
------



Please install the included font "Jokerman.ttf".

DirectX 9.0c --> http://www.microsoft.com/downloads/details.aspx?FamilyID=2da43d38-db71-4c1b-bc6a-9b6652cd92a3&DisplayLang=en

Windows Vista users, read this:
You have to move the included d3drm.dll(direct 3d retained mode) 
to your system32/sysWOW64 folder. You should install DirectX 9.0c too.
You have to run the game as administrator, or you�ll get error messages.
If it still doesn�t work, try experimenting with the compability options.

To start, double-click "TombStone.exe"


--------
Credits:
--------



Design, Programming and Graphics - TheComet/-Alexander Murray
Sounds - DBC sounds
voice  - Stella Murray



--------------
Music credits:
--------------



Third half of the 20th century - EON
Level 1 - Kevin MacLeod
Anxiety - Kevin MacLeod
Menu    - Kevin MacLeod



==================================================



--------------------------------------------------
How To Play:
--------------------------------------------------



You are a strawberry (for now), and you have to solve puzzles and find things hidden in the level to progress.

Arrow keys - move
X - jump
C - Punch
Y - Duck
XX - Double jump
XXX+Run - Triple jump
YX+Run - Long jump
yX - Back Flip
Space - position camera behind player

You can press Enter at any time in-game to save your position. The game saves your positions at major events.



--------------------------------------------------
Disclaimer:
--------------------------------------------------



The author of the game ("TombStone") takes no liability for any damage the game may cause. You 
(the "end user") assume all risks through downloading and/or running of the game. In the event 
a technical error occurs through use of the game, you may reqest assistance from the author, 
however there is no guarantee that the problem will be resolved, nor any compensation for any 
losses incurred.